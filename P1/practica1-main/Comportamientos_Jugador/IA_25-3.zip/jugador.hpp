#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"
#include <queue>
using namespace std;

class ComportamientoJugador : public Comportamiento{

  public:
    ComportamientoJugador(unsigned int size) : Comportamiento(size){
      // Constructor de la clase
      // Dar el valor inicial a las variables de estado
      fil = col = 0;
      brujula = 0;    //0 norte, 1 este, 2 sur, 3 oeste
      ultimaAccion = actIDLE;
      girar_derecha = false;
      bien_situado = false;
      bikini_conseguido = false;
      zapatilla_conseguida = false;
      for (int i=0;i<50;i++){
        for (int j=0;j<50;j++){
          mymapatiempo[i][j] = 0;
        }
      }
      contador_tiempo = 0;
      giroR_pendiente = false;
    }

    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}
    ~ComportamientoJugador(){}

    Action think(Sensores sensores);
    int interact(Action accion, int valor);
    bool buscar_botin(Sensores sensores);
    void pintar_mapa(Sensores sensores);
    Action moverse_tiempo(Sensores sensores);

  private:
  
  // Declarar aquí las variables de estado
  int fil, col, brujula;
  Action ultimaAccion;
  bool girar_derecha;
  bool bien_situado;
  queue<Action> plan_botin;
  bool zapatilla_conseguida;
  bool bikini_conseguido;
  long int mymapatiempo[50][50];
  long int contador_tiempo;
  bool giroR_pendiente;
};

#endif